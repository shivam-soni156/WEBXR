// Simple example function: 
let addingfunction = (x, y) => {
    return x + y;   // The function returns the product of x and y
  }
  
  console.log(addingfunction(3, 5)); //console will log 8
  
  